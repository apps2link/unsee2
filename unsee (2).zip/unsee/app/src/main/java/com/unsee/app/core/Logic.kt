package com.unsee.app.core

import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Zikr
import java.time.Duration
import java.time.ZonedDateTime

enum class WidgetSource(val label: String) {
    AUTO("تلقائي حسب الوقت"),
    MORNING("أذكار الصباح"),
    EVENING("أذكار المساء"),
    ALL("كل الأذكار"),
    FAVORITES("المفضلة"),
}

enum class DayPart { DAWN, DAY, SUNSET, NIGHT }

object Arabic {
    private const val DIGITS = "٠١٢٣٤٥٦٧٨٩"
    fun digits(n: Int): String = digits(n.toString())
    fun digits(s: String): String = buildString {
        for (c in s) append(if (c in '0'..'9') DIGITS[c - '0'] else c)
    }
}

object TimeLogic {
    fun dayPart(hour: Int): DayPart = when (hour) {
        in 4..6 -> DayPart.DAWN
        in 7..15 -> DayPart.DAY
        in 16..18 -> DayPart.SUNSET
        else -> DayPart.NIGHT
    }

    /** الصباح: من آخر الليل حتى بعد الظهر بقليل؛ بعدها المساء. تقريب عملي لا يعتمد على مواقيت الصلاة. */
    fun isMorning(hour: Int): Boolean = hour in 3..13

    fun greeting(hour: Int): String = when (hour) {
        in 4..11 -> "صباح النور"
        in 12..15 -> "نهارك مبارك"
        in 16..18 -> "مساء النور"
        else -> "ليلة هادئة"
    }

    fun suggestedCategory(hour: Int): Category = if (isMorning(hour)) Category.MORNING else Category.EVENING

    /** المدة بالميلي ثانية حتى أقرب وقت قادم يوافق [minuteOfDay] (0..1439) بتوقيت [now]. */
    fun delayUntilNext(now: ZonedDateTime, minuteOfDay: Int): Long {
        val h = (minuteOfDay / 60).coerceIn(0, 23)
        val m = (minuteOfDay % 60).coerceIn(0, 59)
        var target = now.toLocalDate().atTime(h, m).atZone(now.zone)
        if (!target.isAfter(now)) target = now.toLocalDate().plusDays(1).atTime(h, m).atZone(now.zone)
        return Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
    }

    /** أقرب موعد قادم في يوم من الأيام المفعّلة في [days] (قناع بتات)، أو null إن لم يُفعَّل أي يوم. */
    fun delayUntilNextOnDays(now: ZonedDateTime, minuteOfDay: Int, days: Int): Long? {
        if ((days and 127) == 0) return null
        val h = (minuteOfDay / 60).coerceIn(0, 23)
        val m = (minuteOfDay % 60).coerceIn(0, 59)
        for (i in 0..7) {
            val date = now.toLocalDate().plusDays(i.toLong())
            val target = date.atTime(h, m).atZone(now.zone)
            if (target.isAfter(now) && ((days shr (date.dayOfWeek.value - 1)) and 1) == 1) {
                return Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
            }
        }
        return null
    }

    fun formatMinute(minuteOfDay: Int): String {
        val h = minuteOfDay / 60
        val m = minuteOfDay % 60
        val suffix = if (h < 12) "ص" else "م"
        val h12 = when { h == 0 -> 12; h > 12 -> h - 12; else -> h }
        return Arabic.digits("%d:%02d".format(h12, m)) + " " + suffix
    }
}

object WidgetLogic {
    const val ROTATE_SLOT_MS = 30 * 60 * 1000L

    /** مجموعة الأذكار التي يعرضها الودجت وفق المصدر المختار. */
    fun pool(source: WidgetSource, hour: Int, favorites: Set<String>, shortOnly: Boolean): List<Zikr> {
        val base: List<Zikr> = when (source) {
            WidgetSource.AUTO -> AdhkarData.forCategory(TimeLogic.suggestedCategory(hour))
            WidgetSource.MORNING -> AdhkarData.forCategory(Category.MORNING)
            WidgetSource.EVENING -> AdhkarData.forCategory(Category.EVENING)
            WidgetSource.ALL -> AdhkarData.all
            WidgetSource.FAVORITES -> AdhkarData.all.filter { it.id in favorites }.ifEmpty { AdhkarData.all }
        }
        return if (shortOnly) base.filter { it.isShort }.ifEmpty { base } else base
    }

    /** فهرس يدور تلقائيًا كل نصف ساعة، ويزاح يدويًا بزر «التالي». */
    fun rotatingIndex(size: Int, offset: Int, nowMillis: Long, slotMs: Long = ROTATE_SLOT_MS): Int {
        if (size <= 0) return 0
        val slot = (nowMillis / slotMs).toInt()
        return Math.floorMod(offset + slot, size)
    }

    fun manualIndex(size: Int, offset: Int): Int = if (size <= 0) 0 else Math.floorMod(offset, size)
}

object ArabicText {
    /** تطبيع للبحث: إزالة التشكيل والتطويل وتوحيد الألف والتاء المربوطة والياء. */
    fun normalize(s: String): String = buildString {
        for (c in s) {
            if (c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640') continue
            append(
                when (c) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ة' -> 'ه'
                    'ى' -> 'ي'
                    else -> c
                },
            )
        }
    }
}
