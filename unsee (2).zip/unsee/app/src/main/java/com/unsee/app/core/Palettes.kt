package com.unsee.app.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

enum class ThemeId(val label: String, val blurb: String) {
    SOFT("أُنسي الناعم", "فاتح نظيف بألوان هادئة وبطاقات مستديرة"),
    EMERALD("زمردي وذهبي", "الهوية الأساسية للتطبيق"),
    BLACK("أسود فاخر", "أسود عميق مع ذهب هادئ"),
    WHITE("أبيض هادئ", "نظيف ومريح للعين"),
    NIGHT("أزرق ليلي", "سماء الليل الهادئة"),
    PURPLE("بنفسجي", "بنفسجي ملكي ناعم"),
    PATTERN("زخارف هندسية", "نجوم إسلامية خفيفة في الخلفية"),
    NATURE("الطبيعة المتحركة", "فجر ونهار وغروب وليل متحرك"),
}

enum class ThemeMode(val label: String) { SYSTEM("حسب النظام"), LIGHT("فاتح"), DARK("داكن") }

/** ألوان بصيغة ARGB (Long) كي يبقى الملف نقيًّا وقابلًا للاختبار على JVM. */
data class PaletteSpec(
    val bgTop: Long, val bgBottom: Long, val card: Long,
    val text: Long, val textDim: Long,
    val accent: Long, val accentSoft: Long, val onAccent: Long,
    val dark: Boolean,
)

object Palettes {
    private fun p(top: Long, bottom: Long, card: Long, text: Long, dim: Long, accent: Long, soft: Long, on: Long, dark: Boolean) =
        PaletteSpec(top, bottom, card, text, dim, accent, soft, on, dark)

    val EMERALD_DARK = p(0xFF04251E, 0xFF0A4A3B, 0xFF0F3D33, 0xFFFFF4D6, 0xFFC8D6CE, 0xFFE2B857, 0xFFF3D98B, 0xFF04251E, true)
    val EMERALD_LIGHT = p(0xFFF8F3E4, 0xFFEADFC0, 0xFFFFFFFF, 0xFF0B3A2F, 0xFF4A6158, 0xFF7A560F, 0xFFB8892B, 0xFFFFFFFF, false)
    val BLACK_DARK = p(0xFF000000, 0xFF111111, 0xFF1A1A1A, 0xFFF5ECD0, 0xFFBDB6A0, 0xFFD4AF37, 0xFFE8CF7A, 0xFF000000, true)
    val BLACK_LIGHT = p(0xFFFFFDF7, 0xFFF3EEDF, 0xFFFFFFFF, 0xFF1A1A1A, 0xFF595959, 0xFF7A5F0C, 0xFFB8962E, 0xFFFFFFFF, false)
    val WHITE_LIGHT = p(0xFFFFFFFF, 0xFFF1F5F3, 0xFFFFFFFF, 0xFF16302B, 0xFF55706A, 0xFF1F7A66, 0xFF5BB5A0, 0xFFFFFFFF, false)
    val WHITE_DARK = p(0xFF0F1A18, 0xFF16241F, 0xFF1C2C28, 0xFFEAF3F0, 0xFFABC0BA, 0xFF5BC4AB, 0xFF8EDBC8, 0xFF0F1A18, true)
    val NIGHT_DARK = p(0xFF050E24, 0xFF14336B, 0xFF0E2147, 0xFFFFF4D6, 0xFFC3CCE0, 0xFFE2B857, 0xFFF3D98B, 0xFF050E24, true)
    val NIGHT_LIGHT = p(0xFFEAF1FF, 0xFFD3E2FA, 0xFFFFFFFF, 0xFF0B1B3A, 0xFF44557A, 0xFF1D4E9E, 0xFF5B8BD6, 0xFFFFFFFF, false)
    val PURPLE_DARK = p(0xFF150B2B, 0xFF2D1B54, 0xFF241545, 0xFFF3EAFF, 0xFFCBB9E6, 0xFFD9B8FF, 0xFFEBD6FF, 0xFF150B2B, true)
    val PURPLE_LIGHT = p(0xFFF6EFFF, 0xFFE7D8FA, 0xFFFFFFFF, 0xFF2A1450, 0xFF5E4B82, 0xFF6A35B8, 0xFF9F73E0, 0xFFFFFFFF, false)
    val SOFT_LIGHT = p(0xFFE4F5EC, 0xFFF8F8F6, 0xFFFFFFFF, 0xFF14251F, 0xFF55675F, 0xFF0E7A5F, 0xFF5BC4A0, 0xFFFFFFFF, false)
    val SOFT_DARK = p(0xFF0B1F1A, 0xFF10241E, 0xFF16302A, 0xFFEAF6F0, 0xFFA9C2B9, 0xFF5BD6A8, 0xFF8EE6C6, 0xFF06251C, true)
    val NATURE_DARK = p(0xFF050E24, 0xFF14336B, 0xFF0A1530, 0xFFFFF4D6, 0xFFD0D6E6, 0xFFE2B857, 0xFFF3D98B, 0xFF050E24, true)

    fun spec(id: ThemeId, dark: Boolean): PaletteSpec = when (id) {
        ThemeId.SOFT -> if (dark) SOFT_DARK else SOFT_LIGHT
        ThemeId.EMERALD, ThemeId.PATTERN -> if (dark) EMERALD_DARK else EMERALD_LIGHT
        ThemeId.BLACK -> if (dark) BLACK_DARK else BLACK_LIGHT
        ThemeId.WHITE -> if (dark) WHITE_DARK else WHITE_LIGHT
        ThemeId.NIGHT -> if (dark) NIGHT_DARK else NIGHT_LIGHT
        ThemeId.PURPLE -> if (dark) PURPLE_DARK else PURPLE_LIGHT
        ThemeId.NATURE -> NATURE_DARK // الطبيعة المتحركة داكنة دائمًا
    }

    /** ألوان رئيسية مقترحة: (للوضع الداكن، للوضع الفاتح) — كلها تحقق تباينًا مقبولًا على بطاقات الوضع المناسب. */
    val ACCENTS: List<Pair<String, Pair<Long, Long>>> = listOf(
        "ذهبي" to (0xFFE2B857 to 0xFF7A560F),
        "زمردي" to (0xFF5BD6A8 to 0xFF0F6B52),
        "فيروزي" to (0xFF5BC4D6 to 0xFF0E6B7A),
        "وردي" to (0xFFF0A3C0 to 0xFFA32A5E),
        "بنفسجي" to (0xFFD9B8FF to 0xFF6A35B8),
        "برتقالي" to (0xFFFFB070 to 0xFF9A4A0A),
    )

    private fun channel(c: Long, shift: Int): Double {
        val v = ((c shr shift) and 0xFF) / 255.0
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    fun luminance(c: Long): Double = 0.2126 * channel(c, 16) + 0.7152 * channel(c, 8) + 0.0722 * channel(c, 0)

    /** نسبة التباين WCAG بين لونين (1..21). */
    fun contrast(a: Long, b: Long): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
    }
}
