package com.unsee.app.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unsee.app.core.Arabic
import com.unsee.app.core.WidgetSource
import com.unsee.app.data.Store
import com.unsee.app.data.WidgetCfg
import com.unsee.app.ui.ChipRow
import com.unsee.app.ui.ColorDot
import com.unsee.app.ui.GlassCard
import com.unsee.app.ui.LabeledSlider
import com.unsee.app.ui.PillButton
import com.unsee.app.ui.UColors
import com.unsee.app.ui.UnseeTheme

/** شاشة إعداد الودجت «المخصّصة»: تُفتح عند إضافتها، ويُحفظ الإعداد لكل ودجت على حدة. */
class WidgetConfigActivity : ComponentActivity() {
    private val bgNames = listOf("زمردي", "ليلي", "فجر", "أسود", "بنفسجي")
    private val colors = listOf(0xFFFFF4D6, 0xFFE2B857, 0xFFFFFFFF, 0xFFB8F0D2, 0xFFBFD8FF)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(Activity.RESULT_CANCELED) // الرجوع دون حفظ يُلغي إضافة الودجت
        val id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val store = Store.get(this)

        setContent {
            val settings = remember { store.settings() }
            UnseeTheme(settings) {
                var cfg by remember { mutableStateOf(store.widgetCfg(id)) }
                Column(
                    Modifier.fillMaxSize().background(UColors.BgTop).safeDrawingPadding().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("تخصيص الودجت", color = UColors.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text("الخلفية", color = UColors.CreamDim, fontSize = 12.sp)
                        ChipRow((0..4).toList(), { it == cfg.bg }, { bgNames[it] }) { cfg = cfg.copy(bg = it) }
                        Text("لون النص", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            colors.forEach { c -> ColorDot(Color(c), cfg.color == c) { cfg = cfg.copy(color = c) } }
                        }
                        Text("نوع الأذكار", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        val options: List<WidgetSource?> = listOf(null) + WidgetSource.values().toList()
                        ChipRow(options, { it == cfg.source }, { it?.label ?: "حسب الإعداد العام" }) { cfg = cfg.copy(source = it) }
                        LabeledSlider("شفافية الخلفية: ${Arabic.digits(cfg.alpha)}٪", cfg.alpha.toFloat(), 0f..100f) { cfg = cfg.copy(alpha = it.toInt()) }
                    }
                    PillButton("حفظ وإضافة", {
                        store.setWidgetCfg(id, cfg)
                        WidgetRenderer.update(this@WidgetConfigActivity, AppWidgetManager.getInstance(this@WidgetConfigActivity), id, WidgetStyle.CUSTOM)
                        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                        finish()
                    }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
