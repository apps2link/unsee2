package com.unsee.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.dp
import com.unsee.app.core.DayPart
import com.unsee.app.core.TimeLogic
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Scene(
    val top: Color, val mid: Color, val bottom: Color,
    val stars: Float, val leaves: Float, val moon: Float, val sun: Float, val sunY: Float,
)

object Scenes {
    // ألوان أغمق من الإصدار الأول لضمان وضوح النصوص فوق الخلفية
    val Dawn = Scene(Color(0xFF1B2A6B), Color(0xFF4B3A7E), Color(0xFF8A4B66), 0.25f, 0f, 0f, 1f, 0.58f)
    val Day = Scene(Color(0xFF08392C), Color(0xFF0B5A46), Color(0xFF1C7A5F), 0f, 1f, 0f, 1f, 0.12f)
    val Sunset = Scene(Color(0xFF241848), Color(0xFF6F2E57), Color(0xFFA85A4A), 0.15f, 0f, 0f, 1f, 0.5f)
    val Night = Scene(Color(0xFF050E24), Color(0xFF0B1B3A), Color(0xFF173A73), 1f, 0f, 1f, 0f, 0.12f)

    fun forHour(hour: Int): Scene = when (TimeLogic.dayPart(hour)) {
        DayPart.DAWN -> Dawn
        DayPart.DAY -> Day
        DayPart.SUNSET -> Sunset
        DayPart.NIGHT -> Night
    }
}

private class Mote(val x: Float, val y: Float, val size: Float, val phase: Float, val cycles: Int)

private val rnd = Random(42)
private val starSeeds = List(70) { Mote(rnd.nextFloat(), rnd.nextFloat(), 0.5f + rnd.nextFloat() * 1.2f, rnd.nextFloat(), 1) }
private val dustSeeds = List(26) { Mote(rnd.nextFloat(), rnd.nextFloat(), 1.0f + rnd.nextFloat() * 1.8f, rnd.nextFloat(), 1 + rnd.nextInt(3)) }
private val leafSeeds = List(12) { Mote(rnd.nextFloat(), rnd.nextFloat(), 7f + rnd.nextFloat() * 8f, rnd.nextFloat(), 1 + rnd.nextInt(2)) }

private const val TWO_PI = (2.0 * PI).toFloat()

private fun skylinePath(w: Float, h: Float): Path {
    val k = w / 360f
    val y0 = h - 60f * k
    fun px(x: Float) = x * k
    fun py(y: Float) = y0 + y * k
    val p = Path()
    p.moveTo(px(0f), py(50f)); p.lineTo(px(360f), py(50f)); p.lineTo(px(360f), py(60f)); p.lineTo(px(0f), py(60f)); p.close()
    for (x in listOf(40f, 312f)) {
        p.moveTo(px(x), py(60f)); p.lineTo(px(x), py(20f)); p.lineTo(px(x + 4f), py(8f))
        p.lineTo(px(x + 8f), py(20f)); p.lineTo(px(x + 8f), py(60f)); p.close()
    }
    fun dome(x0: Float, x1: Float, top: Float, base: Float) {
        val cx = (x0 + x1) / 2f
        val q = (x1 - x0) * 0.25f
        p.moveTo(px(x0), py(60f)); p.lineTo(px(x0), py(base))
        p.cubicTo(px(x0), py(top + (base - top) * 0.2f), px(cx - q), py(top), px(cx), py(top))
        p.cubicTo(px(cx + q), py(top), px(x1), py(top + (base - top) * 0.2f), px(x1), py(base))
        p.lineTo(px(x1), py(60f)); p.close()
    }
    dome(150f, 210f, 8f, 38f); dome(90f, 130f, 26f, 44f); dome(230f, 270f, 26f, 44f)
    p.moveTo(px(179f), py(8f)); p.lineTo(px(180f), py(0f)); p.lineTo(px(181f), py(8f)); p.close()
    return p
}

/**
 * الخلفية المتحركة: تدرّج يتغير مع الوقت، نجوم متلألئة، هلال، فانوس متوهج، سحب، جزيئات ذهبية، أوراق شجر.
 * كل الحركة تُرسم في مرحلة الرسم فقط (دون إعادة تركيب) وبمؤقّت واحد، وتتوقف عند «تقليل الحركة».
 */
@Composable
fun NatureBackdrop(scene: Scene, reduceMotion: Boolean, particles: Boolean, modifier: Modifier = Modifier) {
    val cspec = tween<Color>(1600)
    val fspec = tween<Float>(1600)
    val top = animateColorAsState(scene.top, cspec, label = "top")
    val mid = animateColorAsState(scene.mid, cspec, label = "mid")
    val bottom = animateColorAsState(scene.bottom, cspec, label = "bottom")
    val stars = animateFloatAsState(scene.stars, fspec, label = "stars")
    val leaves = animateFloatAsState(scene.leaves, fspec, label = "leaves")
    val moon = animateFloatAsState(scene.moon, fspec, label = "moon")
    val sun = animateFloatAsState(scene.sun, fspec, label = "sun")
    val sunY = animateFloatAsState(scene.sunY, fspec, label = "sunY")

    val t: State<Float> = if (reduceMotion) {
        remember { mutableStateOf(0.3f) }
    } else {
        rememberInfiniteTransition(label = "backdrop").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing)),
            label = "t",
        )
    }

    Box(
        modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val skyline = skylinePath(w, h)
                val moonR = w * 0.07f
                val moonC = Offset(w * 0.82f, h * 0.12f)
                val moonPath = Path.combine(
                    PathOperation.Difference,
                    Path().apply { addOval(Rect(moonC, moonR)) },
                    Path().apply { addOval(Rect(moonC + Offset(moonR * 0.55f, -moonR * 0.2f), moonR * 0.85f)) },
                )
                onDrawBehind {
                    val tt = t.value
                    drawRect(Brush.verticalGradient(listOf(top.value, mid.value, bottom.value)))

                    // الشمس
                    val sunA = sun.value
                    if (sunA > 0.01f) {
                        val c = Offset(w * 0.8f, h * sunY.value)
                        drawCircle(
                            Brush.radialGradient(listOf(UColors.Gold.copy(alpha = 0.5f * sunA), Color.Transparent), center = c, radius = w * 0.55f),
                            radius = w * 0.55f, center = c,
                        )
                    }
                    // القمر
                    val moonA = moon.value
                    if (moonA > 0.01f) {
                        drawCircle(
                            Brush.radialGradient(listOf(UColors.GoldSoft.copy(alpha = 0.3f * moonA), Color.Transparent), center = moonC, radius = moonR * 4f),
                            radius = moonR * 4f, center = moonC,
                        )
                        drawPath(moonPath, UColors.GoldSoft.copy(alpha = moonA))
                    }
                    // النجوم
                    val starA = stars.value
                    if (starA > 0.01f) {
                        for (s in starSeeds) {
                            val tw = 0.5f + 0.5f * sin(TWO_PI * (tt * 12f + s.phase))
                            drawCircle(
                                UColors.Cream.copy(alpha = starA * (0.25f + 0.75f * tw)),
                                radius = s.size * density,
                                center = Offset(s.x * w, s.y * h * 0.62f),
                            )
                        }
                    }
                    // السحب
                    for (i in 0 until 3) {
                        val cw = w * (0.45f + 0.1f * i)
                        val x = ((tt + i * 0.37f) % 1f) * (w + cw) - cw
                        drawOval(UColors.Cream.copy(alpha = 0.06f), Offset(x, h * (0.18f + 0.13f * i)), Size(cw, h * 0.035f))
                    }
                    // الفانوس
                    val lx = w * 0.14f
                    val ly = h * 0.085f
                    drawLine(UColors.Gold.copy(alpha = 0.7f), Offset(lx, 0f), Offset(lx, ly), strokeWidth = 1.5f * density)
                    val glowC = Offset(lx, ly + 14f * density)
                    val glow = 0.25f + 0.15f * sin(TWO_PI * tt * 12f)
                    drawCircle(
                        Brush.radialGradient(listOf(UColors.Gold.copy(alpha = glow), Color.Transparent), center = glowC, radius = 46f * density),
                        radius = 46f * density, center = glowC,
                    )
                    drawRoundRect(
                        Brush.verticalGradient(listOf(UColors.GoldSoft, UColors.Gold, Color(0xFFB8862B)), startY = ly, endY = ly + 28f * density),
                        topLeft = Offset(lx - 9f * density, ly), size = Size(18f * density, 28f * density),
                        cornerRadius = CornerRadius(6f * density),
                    )
                    drawCircle(Color(0xFFFFF1B8), radius = 3f * density, center = glowC)

                    // الأوراق
                    val leafA = leaves.value
                    if (leafA > 0.01f) {
                        for (l in leafSeeds) {
                            val y = (l.y + tt * l.cycles) % 1f
                            val x = l.x + 0.05f * sin(TWO_PI * (tt * 2f * l.cycles + l.phase))
                            val c = Offset(x * w, y * h)
                            rotate(degrees = 360f * (tt * l.cycles + l.phase), pivot = c) {
                                drawOval(
                                    Color(0xFF8FE3B0).copy(alpha = 0.32f * leafA),
                                    Offset(c.x - l.size * density, c.y - l.size * 0.45f * density),
                                    Size(l.size * 2f * density, l.size * 0.9f * density),
                                )
                            }
                        }
                    }
                    // الجزيئات الذهبية
                    if (particles) {
                        for (d in dustSeeds) {
                            val y = 1f - ((tt * d.cycles + d.y) % 1f)
                            val x = d.x + 0.02f * sin(TWO_PI * (tt * 2f * d.cycles + d.phase))
                            val a = 0.25f + 0.35f * (0.5f + 0.5f * sin(TWO_PI * (tt * 6f * d.cycles + d.phase)))
                            drawCircle(UColors.GoldSoft.copy(alpha = a), radius = d.size * density, center = Offset(x * w, y * h))
                        }
                    }
                    // أفق المساجد
                    drawPath(skyline, Color(0xFF050D1F).copy(alpha = 0.55f))
                }
            },
    )
}


/** خلفية ساكنة بتدرج الثيم، مع نجوم إسلامية ثمانية خفيفة جدًّا عند اختيار ثيم «الزخارف الهندسية». */
@Composable
fun StaticBackdrop(modifier: Modifier = Modifier) {
    val pattern = UColors.pattern
    Box(
        modifier
            .fillMaxSize()
            .drawWithCache {
                val cell = 72.dp.toPx()
                val r = cell * 0.36f
                val star = Path().apply {
                    for (k in 0 until 16) {
                        val rad = if (k % 2 == 0) r else r * 0.62f
                        val a = (k * 22.5f - 90f) * (PI.toFloat() / 180f)
                        val x = rad * kotlin.math.cos(a)
                        val y = rad * kotlin.math.sin(a)
                        if (k == 0) moveTo(x, y) else lineTo(x, y)
                    }
                    close()
                }
                onDrawBehind {
                    drawRect(Brush.verticalGradient(listOf(UColors.BgTop, UColors.BgBottom)))
                    if (pattern) {
                        val col = UColors.Gold.copy(alpha = 0.08f)
                        val stroke = Stroke(width = 1.dp.toPx())
                        var row = 0
                        var y = cell / 2
                        while (y < size.height + cell) {
                            var x = if (row % 2 == 0) cell / 2 else cell
                            while (x < size.width + cell) {
                                translate(x, y) { drawPath(star, col, style = stroke) }
                                x += cell
                            }
                            y += cell / 2
                            row++
                        }
                    }
                }
            },
    )
}
