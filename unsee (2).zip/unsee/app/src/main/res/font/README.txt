لاستخدام خط Amiri: نزّل Amiri-Regular.ttf (ترخيص OFL) من fonts.google.com/specimen/Amiri
وضعه هنا باسم  amiri_regular.ttf  (حروف صغيرة وشرطة سفلية). يلتقطه التطبيق تلقائيًا.
بدونه يستخدم التطبيق خط النسخ العربي المدمج في Android.
